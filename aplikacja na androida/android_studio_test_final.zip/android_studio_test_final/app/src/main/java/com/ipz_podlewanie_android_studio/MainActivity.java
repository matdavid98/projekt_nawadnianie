package com.ipz_podlewanie_android_studio;

import androidx.appcompat.app.AppCompatActivity;

import android.app.VoiceInteractor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    Button p1, p2;
    TextView tekst;
    CheckBox boks;
    TextView tekst_id;
    ProgressBar progres;
    String data="";
    Integer ilosc=0;
    int id = 1;
    private android.os.Handler mHandl = new android.os.Handler();
    String daneG="";
    ListView lista;
ArrayList<HashMap<String,String>> listaDanych=new ArrayList<HashMap<String,String>>();
private SimpleAdapter sa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        p1 = (Button) findViewById(R.id.p1);
        p2 = (Button) findViewById(R.id.p2);
        tekst = findViewById(R.id.textView);
        boks = findViewById(R.id.checkBox);
        tekst_id = findViewById(R.id.editTextNumber);
        progres=(ProgressBar) findViewById(R.id.progressBar);
        lista= findViewById(R.id.liastofData);

        lista.setOnClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l)
            {

            }
        });

        p2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "To jest TOAST", Toast.LENGTH_LONG).show();
                sendR(tekst_id.getText().toString());
            }
        });

        p1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("Info", "Jestesmy przed if");
                if (boks.isChecked()) {
                    tekst.setText("ZAZNACZONE");
                    Log.d("Info", "Jestesmy w zaznaczony");
                } else {
                    tekst.setText("NIE");
                    Log.d("Info", "Jestesmy w niezaznaczonym");
                }
            }

        });


    }

}
    private void sendLista() {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        JSONObject jsonObjectRequest = new JSONObject(Request.Method.GET, "http://felixl120.eu.pythonanywhere.com/", null, new Response.Listener<JSONArray>() {


            @Override
            public void onResponse(JSONArray response) {
                try {
                    HashMap<String, String> item;
                    for (int i = 0; i < response.length(); i++) {
                        JSONObject dane = response.getJSONObject(i);
                        //data = data + dane.getString("full name") + "     " + dane.getString("created at") + "\n";
                        item = new HashMap<String,String>();
                        item.put("line_a",dane.getString(full_name));
                        item.put("line_b",dane.getString(created_at));
                    }
                    sa = new SimpleAdapter(getApplicationContext(),listaDanych,R.layout.twolines,new String[]{"line_a","line_b"},
                            new int[] {R.id.line_a , R.id.line_b});

                    //daneG=data;
                    //mHandl.postDelayed(addProgres,100);

                    //tekst.setText(data);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("blad", error.toString());
            }

        });
        requestQueue.add(JsonObjectRequest);
    }
    private Runnable addProgres= new Runnable() {
        @Override
        public void run()
        {
tekst.setText(data);
progres.setProgress(id*10);

        }
    };
}
